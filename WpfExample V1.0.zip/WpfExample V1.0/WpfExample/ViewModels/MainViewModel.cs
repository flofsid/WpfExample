﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfExample.ViewModels
{
    public class MainViewModel : Screen
    {
        #region ****************** Init and ctor ******************
        static MainViewModel _Instance;
        public static MainViewModel Instance
        {
            get
            {
                if (_Instance == null) _Instance = new MainViewModel();
                return _Instance;
            }
        }
        public MainViewModel()
        {
            NotifyOfPropertyChange();
        }
        #endregion
    }
}
